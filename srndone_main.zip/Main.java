////NANDHA GOPAL ////
import java.util.*;
import java.util.concurrent.TimeUnit;

class Question {
    private String questionText;
    private String[] options;
    private int correctAnswerIndex;

   
    public Question(String questionText, String[] options, int correctAnswerIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
    }

    // Getter methods
    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public int getCorrectAnswerIndex() {
        return correctAnswerIndex;
    }
}

public class Main {
    private Queue<Question> questionQueue;
    private HashMap<String, Integer> userScores; 
    private ArrayList<Question> questionList;
    private Scanner scanner;


    public Main() {
        questionQueue = new LinkedList<>();
        userScores = new HashMap<>();
        questionList = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

  
    public void addQuestion(Question question) {
        questionList.add(question);
        questionQueue.add(question);
    }

    public Question getUserDefinedQuestion() {
        System.out.print("Enter your question: ");
        String questionText = scanner.nextLine();

        String[] options = new String[4];
        System.out.println("Enter 4 options:");
        for (int i = 0; i < 4; i++) {
            System.out.print("Option " + (i + 1) + ": ");
            options[i] = scanner.nextLine();
        }

        System.out.print("Enter the number (1-4) of the correct answer: ");
        int correctAnswerIndex = scanner.nextInt();
        scanner.nextLine(); 

        return new Question(questionText, options, correctAnswerIndex);
    }

    
    public void startQuiz(String userName) {
        int score = 0;
        long startTime = System.currentTimeMillis();
        int timeLimit = 30;

        for (int i = 0; i < questionList.size(); i++) {
            Question question = questionQueue.poll();
            System.out.println("Q" + (i + 1) + ": " + question.getQuestionText());

            String[] options = question.getOptions();
            for (int j = 0; j < options.length; j++) {
                System.out.println((j + 1) + ". " + options[j]);
            }

            long questionStartTime = System.currentTimeMillis();
            long timeRemaining = timeLimit;

        
            while (timeRemaining > 0) {
                if (System.currentTimeMillis() - questionStartTime > 1000) {
                    timeRemaining = timeLimit - (TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis() - questionStartTime));
                }
                System.out.print("Please enter your answer (1-" + options.length + "): ");
                if (scanner.hasNextInt()) {
                    int userAnswer = scanner.nextInt();
                    if (userAnswer == question.getCorrectAnswerIndex()) {
                        System.out.println("Correct!\n");
                        score++;
                    } else {
                        System.out.println("Incorrect! The correct answer was: " + options[question.getCorrectAnswerIndex() - 1] + "\n");
                    }
                    break;
                } else {
                    System.out.println("Please enter a valid number.");
                    scanner.next();
                }
            }

            if (timeRemaining <= 0) {
                System.out.println("\nTime's up! The correct answer was: " + options[question.getCorrectAnswerIndex() - 1] + "\n");
            }
        }

        // Store and display results
        storeUserScore(userName, score);
        displayResults(userName, score);
    }

    private void storeUserScore(String userName, int score) {
        userScores.put(userName, score);
    }

    public void displayResults(String userName, int score) {
        System.out.println("Quiz Over!");
        System.out.println("Your score: " + score + "/" + questionList.size());
        double percentage = ((double) score / questionList.size()) * 100;
        System.out.println("Percentage: " + percentage + "%");

        if (percentage >= 80) {
            System.out.println("Excellent! You're a quiz master.");
        } else if (percentage >= 50) {
            System.out.println("Good job! Keep it up.");
        } else {
            System.out.println("Better luck next time!");
        }

        // Display user score history
        System.out.println("\nScore History:");
        for (Map.Entry<String, Integer> entry : userScores.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public static void main(String[] args) {
        Main quizSystem = new Main();

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of questions you want to add to the quiz: ");
        int numQuestions = scanner.nextInt();
        scanner.nextLine(); 

       
        for (int i = 0; i < numQuestions; i++) {
            System.out.println("\nAdding Question " + (i + 1));
            Question userQuestion = quizSystem.getUserDefinedQuestion();
            quizSystem.addQuestion(userQuestion);
        }

        System.out.print("Enter your name: ");
        String userName = scanner.nextLine();

        quizSystem.startQuiz(userName);
    }
}
